const WeatherList = {
  DayTime: {
    image: "images/DayTime.png",
    announce: '<span style="color: red;">아침</span>이 되었습니다. 생존자들은 대화를 시작해주세요.'
  },
  NightTime: {
    image: "images/NightTime.png",
    announce: '<span style="color: red;">밤</span>이 되었습니다. 마피아들의 시간이 시작됩니다.'
  },
  VoteTime: {
    image: "images/VoteTime.png",
    announce: '<span style="color: red;">투표 시간</span>이 되었습니다. 생존자들은 마피아를 지목해주세요.'
  }
};

const playerimages = {
  player1: "images/player/player1.png",
  player2: "images/player/player2.png",
  player3: "images/player/player3.png",
  player4: "images/player/player4.png",
  player5: "images/player/player5.png",
  player6: "images/player/player6.png",
  player7: "images/player/player7.png",
  player8: "images/player/player8.png",
  player9: "images/player/player9.png"
};

const playerRoles = {
  player1:"innocent",
  player2:"innocent",
  player3:"mafia",
  player4:"innocent",
  player5:"doctor",
  player6:"innocent",
  player7:"innocent",
  player8:"mafia",
  player9:"innocent",
  user:"innocent"
};

const roleImages = {
  innocent: "images/Innocent.png",
  mafia: "images/MafiaKnife.png",
  doctor: "images/DoctorMedkit.png",
  unknown: "images/QuestionImg.png"
};

function renderPlayers(playerCount) {
  const leftContainer = document.getElementById("leftPlayers");
  const rightContainer = document.getElementById("rightPlayers");

  leftContainer.innerHTML = '';
  rightContainer.innerHTML = '';

  for (let i = 1; i <= playerCount; i++) {
    const playerId = "player" + i;
    const isUser = (i === playerCount);
    const playerBox = document.createElement("div");
    playerBox.className = "player-box";

    const roleImgSrc = isUser ? roleImages[playerRoles["user"]] : roleImages["unknown"];
    const nameLabel = isUser ? "User" : `player${i}`;
    const playerImgSrc = isUser ? playerimages["player1"] : playerimages[nameLabel];

    playerBox.innerHTML = `
      <img class="player-icon-img" src="${playerImgSrc}" alt="플레이어" id="${playerId}avatarImg" />
      <img class="player-role-img" src="${roleImgSrc}" alt="role" id="${playerId}roleImg" />
      <div class="player-name">${nameLabel}</div>
      <div class="vote-indicator" id="vote-indicator-${playerId}"></div>
    `;
    playerBox.id = `${playerId}Box`;

    if (i <= Math.ceil(playerCount / 2)) {
      leftContainer.appendChild(playerBox);
    } else {
      rightContainer.appendChild(playerBox);
    }
  }
}

var VoteSum = [3,0,4,0,2,0,1,0,0,0];

function updateVoteIndicators() {
  for (let i = 1; i <= 9; i++) {
    const indicator = document.getElementById(`vote-indicator-player${i}`);
    if (indicator) {
      const count = VoteSum[i];
      indicator.innerHTML = "●".repeat(count);
    }
  }
}

function announceMessage(text){
  const chatContent = document.getElementById("chatContent");
  const announceMessage = document.createElement("div");
  announceMessage.className = "announce-box";

  announceMessage.innerHTML=`
    <p class="announce-message">${text}</p>
  `;

  chatContent.appendChild(announceMessage);
  chatContent.scrollTop = chatContent.scrollHeight;
}

function PlayerDeadImage(name) {
  const box = document.getElementById(`${name}Box`);
  if (!box) return;
  const deathImg = document.createElement("img");
  deathImg.className = "player-death-img";
  deathImg.src = "images/DeathMark.png";
  deathImg.alt = "사망";
  box.appendChild(deathImg);
}

function PlayerRoleReveal(name) {
  const roleImg = document.getElementById(`${name}roleImg`);
  if (!roleImg) return;
  roleImg.src = roleImages[playerRoles[name]] || roleImages["unknown"];
}

function PlayerDead(name){
  PlayerDeadImage(name);
  PlayerRoleReveal(name);
}

function startVotePhase() {
  const totalPlayers = Object.keys(playerimages).length;

  for (let i = 1; i <= totalPlayers; i++) {
    const playerId = "player" + i;
    if (playerId === "user") continue;

    const playerBox = document.getElementById(`${playerId}Box`);
    if (!playerBox) continue;

    const voteButton = document.createElement("button");
    voteButton.innerText = "투표";
    voteButton.className = "vote-button";
    voteButton.id = `vote-btn-${i}`;
    voteButton.onclick = () => castVote(i);

    playerBox.appendChild(voteButton);
  }
}

function castVote(target) {
  announceMessage(`player${target}에게 투표하였습니다.`);

  const voteButtons = document.querySelectorAll(".vote-button");
  voteButtons.forEach(btn => btn.remove());

  VoteSum[parseInt(target)]++;

  updateVoteIndicators();
}

document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("messageInput");
  const sendButton = document.getElementById("sendButton");
  const chatContent = document.getElementById("chatContent");
  const WeatherImage = document.getElementById("weatherImage");

  const urlParams = new URLSearchParams(window.location.search);
  const count = parseInt(urlParams.get('count')) || 8;

  renderPlayers(count);

  function addPlayerMessage(text) {
    if (!text.trim()) return;

    const messageBox = document.createElement("div");
    messageBox.className = "chat-message-user";

    messageBox.innerHTML = `
      <div class="message-bubble-user">
        <span class="message-text">${text}</span>
      </div>
    `;

    chatContent.appendChild(messageBox);
    chatContent.scrollTop = chatContent.scrollHeight;
  }

  function addBotMessage(text, playerName) {
    if (!text.trim()) return;

    const messageBox = document.createElement("div");
    messageBox.className = "chat-message-bot";

    messageBox.innerHTML = `
      <div class="bot-chat-image-context">
        <img src="${playerimages[playerName]}" alt="이미지" class="bot-image" />
        <div class="bot-name">${playerName}</div>
      </div>
      <div class="message-bubble-bot">
        <span class="message-text">${text}</span>
      </div>
    `;

    chatContent.appendChild(messageBox);
    chatContent.scrollTop = chatContent.scrollHeight;
  }

  function ChangeTime(text){
    const announceMessage = document.createElement("div");
    announceMessage.className = "announce-box";

    WeatherImage.style.backgroundImage = `url(${WeatherList[text].image})`;

    announceMessage.innerHTML=`
      <p class="announce-message">${WeatherList[text].announce}</p>
    `;

    chatContent.appendChild(announceMessage);
    chatContent.scrollTop = chatContent.scrollHeight;
  }

  function addExecuteAnnounce(playerName, TieBool){
    const announceMessage = document.createElement("div");
    announceMessage.className = "announce-box";

    if (TieBool === true){
      announceMessage.innerHTML=`
        <p class="announce-message">투표가 동점으로 <span style="color: red;">아무도</span> 죽지 않았습니다.</p>
      `;

      chatContent.appendChild(announceMessage);
      chatContent.scrollTop = chatContent.scrollHeight;
    } else if (TieBool === false){
      announceMessage.innerHTML=`
        <p class="announce-message">투표결과로 <span style="color: red;">${playerName}</span>이(가) 처형되었습니다.</p>
      `;

      const announceMessage1 = document.createElement("div");
      announceMessage1.className = "announce-box";

      announceMessage1.innerHTML=`
        <p class="announce-message"><span style="color: red;">${playerName}</span>은(는) <span style="color: red;">마피아</span> 였습니다.</p>
      `;

      chatContent.appendChild(announceMessage);
      chatContent.scrollTop = chatContent.scrollHeight;

      chatContent.appendChild(announceMessage1);
      chatContent.scrollTop = chatContent.scrollHeight;
    }
  }

  function addNightAnnounce(DeathPlayer, HealPlayer){
    const announceMessage1 = document.createElement("div");
    announceMessage1.className = "announce-box";

    const announceMessage2 = document.createElement("div");
    announceMessage2.className = "announce-box";

    announceMessage1.innerHTML=`
      <p class="announce-message">밤 중 마피아에 의해 <span style="color: red;">${DeathPlayer}</span>이(가) 살해되었습니다.</p>
    `;
    announceMessage2.innerHTML=`
      <p class="announce-message">밤 중 의사가 <span style="color: green;">${HealPlayer}</span>을(를) 살렸습니다.</p>
    `;

    chatContent.appendChild(announceMessage1);
    chatContent.scrollTop = chatContent.scrollHeight;
    chatContent.appendChild(announceMessage2);
    chatContent.scrollTop = chatContent.scrollHeight;

    if (HealPlayer === DeathPlayer){
      const announceMessage3 = document.createElement("div");
      announceMessage3.className = "announce-box";

      announceMessage3.innerHTML=`
        <p class="announce-message">의사에 의해 <span style="color: green;">${HealPlayer}</span>가 생존하였습니다.</p>
      `;

      chatContent.appendChild(announceMessage3);
      chatContent.scrollTop = chatContent.scrollHeight;
    }
  }

  sendButton.addEventListener("click", () => {
    const message = input.value;
    addPlayerMessage(message);
    input.value = "";
    input.focus();
  });

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      sendButton.click();
    }
  });
});
