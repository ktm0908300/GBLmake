// -- 수정된 maingame.js --

const roleImages = {
  "마피아": "/static/images/MafiaKnife.png",
  "의사": "/static/images/DoctorMedkit.png",
  "시민": "/static/images/Innocent.png",
  "unknown": "/static/images/QuestionImg.png"
};

let players = [];
let playerCount = 0;
let phase = "waiting"; // waiting → night → day → vote
let votes = {};
let aliveCount = 0;

let mafiaTargetId = null; // 마피아가 밤에 선택한 대상

function shuffle(array) {
  return array
    .map(value => ({ value, sort: Math.random() }))
    .sort((a,b) => a.sort - b.sort)
    .map(({value}) => value);
}

function assignRoles(count) {
  let roles = ["마피아", "의사"];
  for (let i = 2; i < count; i++) roles.push("시민");
  roles = shuffle(roles);

  players = [];
  for(let i=0; i<count; i++){
    players.push({
      id: i+1,
      role: roles[i],
      alive: true,
      votesReceived: 0
    });
  }
  aliveCount = count;
}

function renderPlayers() {
  const leftContainer = document.getElementById("leftPlayers");
  const rightContainer = document.getElementById("rightPlayers");
  leftContainer.innerHTML = "";
  rightContainer.innerHTML = "";

  for(let i=0; i<players.length; i++){
    const p = players[i];
    const box = document.createElement("div");
    box.className = "player-box";
    box.id = `player${p.id}Box`;

    let roleImgSrc = roleImages["unknown"];
    if (!p.alive) roleImgSrc = roleImages[p.role]; // 죽으면 역할 공개

    box.innerHTML = `
      <img class="player-icon-img" src="/static/images/player/player${(p.id % 9) + 1}.png" alt="플레이어${p.id}">
      <img class="player-role-img" src="${roleImgSrc}" alt="role">
      <div class="player-name">player${p.id}${p.alive ? "" : " (사망)"}</div>
      <div class="vote-indicator" id="vote-indicator-player${p.id}"></div>
    `;

    if(i < Math.ceil(players.length/2)) leftContainer.appendChild(box);
    else rightContainer.appendChild(box);
  }
}

function updateVoteIndicators() {
  for(let p of players){
    const el = document.getElementById(`vote-indicator-player${p.id}`);
    if(el) el.textContent = "●".repeat(p.votesReceived);
  }
}

function announce(text){
  const chatContent = document.getElementById("chatContent");
  const div = document.createElement("div");
  div.className = "announce-box";
  div.innerHTML = `<p class="announce-message">${text}</p>`;
  chatContent.appendChild(div);
  chatContent.scrollTop = chatContent.scrollHeight;
}

function addPlayerMessage(text){
  if(!text.trim()) return;
  const chatContent = document.getElementById("chatContent");
  const div = document.createElement("div");
  div.className = "chat-message-user";
  div.innerHTML = `<div class="message-bubble-user"><span class="message-text">${text}</span></div>`;
  chatContent.appendChild(div);
  chatContent.scrollTop = chatContent.scrollHeight;
}

function addBotMessage(text, playerId){
  if(!text.trim()) return;
  const chatContent = document.getElementById("chatContent");
  const div = document.createElement("div");
  div.className = "chat-message-bot";
  div.innerHTML = `
    <div class="bot-chat-image-context">
      <img src="/static/images/player/player${(playerId % 9) + 1}.png" alt="player${playerId}" class="bot-image" />
      <div class="bot-name">player${playerId}</div>
    </div>
    <div class="message-bubble-bot">
      <span class="message-text">${text}</span>
    </div>`;
  chatContent.appendChild(div);
  chatContent.scrollTop = chatContent.scrollHeight;
}

function startGame() {
  if(phase !== "waiting") return;
  announce("게임을 시작합니다!");

  assignRoles(playerCount);
  renderPlayers();
  phase = "night";
  announce("밤이 되었습니다.");

  startNightPhase();
}

// 밤 단계 시작: 마피아가 제거할 대상을 선택할 수 있도록 이벤트 설정
function startNightPhase(){
  mafiaTargetId = null; // 초기화

  // 살아있는 마피아 찾기 (1명)
  const aliveMafias = players.filter(p => p.role === "마피아" && p.alive);
  if(aliveMafias.length === 0){
    announce("마피아가 모두 사망하여 시민팀이 승리했습니다!");
    // 게임 종료 및 결과 페이지 이동
    phase = "waiting";
    setTimeout(() => {
      window.location.href = "/result";  // 결과 페이지 이동
    }, 3000);
    return;
  }

  const mafiaPlayer = aliveMafias[0]; // 마피아는 1명이라 가정

  if(mafiaPlayer.id === 8){
    // 마피아가 실제 플레이어(player8)인 경우 → 클릭 선택 허용
    announce("제거할 대상을 선택하세요.")
    const alivePlayers = players.filter(p => p.alive && p.id !== mafiaPlayer.id);
    for(let p of alivePlayers){
      const box = document.getElementById(`player${p.id}Box`);
      if(!box) continue;

      box.style.cursor = "pointer"; // 클릭 가능 커서
      box.onclick = () => {
        mafiaTargetId = p.id;
        announce(`마피아가 player${p.id}를 선택했습니다.`);
        cleanupNightPhase();    // 밤 선택 UI 초기화
        processNightResult();   // 밤 결과 처리 시작
      };
    }
  } else {
    // 마피아가 AI(LLM)인 경우 → 랜덤 자동 선택

    announce(`마피아가 밤에 제거할 대상을 선택 중입니다...`);

    setTimeout(() => {
      const alivePlayers = players.filter(p => p.alive && p.id !== mafiaPlayer.id);
      mafiaTargetId = alivePlayers[Math.floor(Math.random() * alivePlayers.length)].id;
      announce(`마피아가 player${mafiaTargetId}를 제거 대상으로 선택했습니다.`);
      processNightResult();
    }, 2000); // 2초 뒤 자동 선택
  }
}

// 밤 단계 종료 시 선택 UI, 이벤트 제거 함수
function cleanupNightPhase(){
  for(let p of players){
    const box = document.getElementById(`player${p.id}Box`);
    if(box){
      box.style.cursor = "default";
      box.onclick = null;  // 클릭 이벤트 제거
    }
  }
}

// 밤 결과 처리 함수: 의사가 살릴 사람 랜덤 선택, 마피아가 공격한 대상 사망 처리
function processNightResult(){
  // 살아있는 의사 찾기
  const doctor = players.find(p => p.role === "의사" && p.alive);
  let savedId = null;

  if(doctor){
    // 의사가 랜덤으로 생존자 한 명 치료 (자기 자신 포함 가능)
    const candidates = players.filter(p => p.alive);
    savedId = candidates[Math.floor(Math.random() * candidates.length)].id;
    announce(`의사가 player${savedId}를 치료했습니다.`);
  }

  // 마피아가 공격한 대상이 치료받지 못했으면 사망 처리
  if(mafiaTargetId !== savedId){
    const victim = players.find(p => p.id === mafiaTargetId);
    if(victim && victim.alive){
      victim.alive = false;
      aliveCount--;
      announce(`player${victim.id}가 밤에 마피아에게 제거되었습니다. 역할: ${victim.role}`);

      // 마피아 사망 여부 다시 체크 (게임 종료 가능)
      const mafiaAlive = players.filter(p => p.alive && p.role === "마피아").length;
      if(mafiaAlive === 0){
        announce("마피아가 모두 사망하여 시민팀이 승리했습니다!");
        phase = "waiting";
        setTimeout(() => {
          window.location.href = "/result";  // 결과 페이지 이동
        }, 3000);
        return;
      }
    }
if(victim.id === 8){
      // 플레이어8 사망 시 즉시 게임 종료
      announce("유저가 사망하여 게임이 종료됩니다. 결과 페이지로 이동합니다.");
      phase = "waiting";
      setTimeout(() => {
        window.location.href = "/result";
      }, 3000);
      return;
    }
  }
 else {
  announce("마피아의 공격이 의사에 의해 막혔습니다.");
}
  renderPlayers();

  // 3초 후 낮 단계 진행
  setTimeout(() => {
    proceedToDay();
  }, 3000);
}


function proceedToDay(){
  phase = "day";
  announce("아침이 되었습니다. 토론 시간을 시작합니다. (2분)");
  setTimeout(() => {
    announce("토론 시간이 종료되었습니다.");
    startVotingPhase();
  }, 120000); // 2분 (120,000ms)
}

function startVotingPhase(){
  phase = "vote";
  announce("투표 시간을 시작합니다! (30초)");

  votes = {};
  for(let p of players){
    p.votesReceived = 0;
  }
  renderPlayers();

  // 투표 버튼 생성
  for(let p of players){
    if(!p.alive) continue;
    const box = document.getElementById(`player${p.id}Box`);
    if(!box) continue;
    const btn = document.createElement("button");
    btn.className = "vote-button";
    btn.textContent = "투표";
    btn.onclick = () => castVote(p.id);
    box.appendChild(btn);
  }

  // 30초 후 투표 마감 자동 처리
  setTimeout(() => {
    if(phase === "vote") {
      announce("투표 시간이 종료되었습니다.");
      finishVoting();
    }
  }, 30000);
}

function castVote(targetId){
  if(phase !== "vote") return;
  votes[targetId] = (votes[targetId] || 0) + 1;

  // 투표 버튼 제거
  const voteButtons = document.querySelectorAll(".vote-button");
  voteButtons.forEach(btn => btn.remove());

  finishVoting();
}

function finishVoting(){
  phase = "waiting"; // 잠시 대기 상태로 변경
  // 집계
  for(let p of players){
    p.votesReceived = votes[p.id] || 0;
  }
  updateVoteIndicators();

  // 결과 처리
  let maxVotes = 0;
  let candidates = [];
  for(let p of players){
    if(!p.alive) continue;
    if(p.votesReceived > maxVotes){
      maxVotes = p.votesReceived;
      candidates = [p];
    } else if(p.votesReceived === maxVotes){
      candidates.push(p);
    }
  }

  if(maxVotes === 0){
    announce("아무도 투표하지 않아 제거된 사람이 없습니다.");
  }
  else if(candidates.length === 1){
    const killed = candidates[0];
    killed.alive = false;
    aliveCount--;
    announce(`player${killed.id}가 투표로 제거되었습니다. 역할: ${killed.role}`);
  } else {
    announce("투표가 동점으로 아무도 제거되지 않았습니다.");
  }

  renderPlayers();

  if(checkWin()){
    announce("게임 종료!");
    phase = "waiting";
    setTimeout(() => {
    window.location.href = "/result?count=" + playerCount; // 결과 페이지 URL로 + 인원수 파라미터 포함
  }, 3000);

  } else {
    setTimeout(() => {
      phase = "night";
      announce("밤이 되었습니다. 마피아가 제거할 대상을 선택하세요.");
      startNightPhase();
    }, 4000);
  }
}

function checkWin(){
  const mafiaAlive = players.filter(p => p.alive && p.role === "마피아").length;
  const othersAlive = players.filter(p => p.alive && p.role !== "마피아").length;

  if(mafiaAlive === 0){
    announce("시민팀의 승리!");
    return true;
  } else if(mafiaAlive >= othersAlive){
    announce("마피아팀의 승리!");
    return true;
  }
  return false;
}

document.addEventListener("DOMContentLoaded", () => {
  const urlParams = new URLSearchParams(window.location.search);
  playerCount = parseInt(urlParams.get("count")) || 8;

  renderPlayers();

  // 채팅 관련
  const input = document.getElementById("messageInput");
  const sendBtn = document.getElementById("sendButton");

  sendBtn.onclick = () => {
    if(input.value.trim() === "") return;
    addPlayerMessage(input.value.trim());
    input.value = "";
  };

  input.addEventListener("keydown", (e) => {
    if(e.key === "Enter"){
      sendBtn.click();
    }
  });

  // 게임 시작
  startGame();
});
